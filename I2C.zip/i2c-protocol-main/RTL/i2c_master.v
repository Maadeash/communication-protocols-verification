module master(
  input clk,rst,
  input [7:0]w_data,
  input [6:0]addr,
  input rw,
  input enable,
  output reg [7:0]dout=8'd0,
  inout i2c_sda,
  inout i2c_scl
);
  localparam idle=0;
  localparam start=1;
  localparam address=2;
  localparam read_ack=3;
  localparam write_data=4;
  localparam read_ack2=5;
  localparam read_data=6;
  localparam write_ack=7;
  localparam stop=8;

  reg sda_out;
  reg i2c_sda_enable;
  reg i2c_scl_enable;
  reg i2c_clk=1;
  parameter divide_by=4;
  reg [3:0]counter2=0;
  reg [3:0]counter=0;
  reg [3:0]state;
  reg [7:0]saved_data;
  reg [7:0]saved_addr;
  reg [7:0]buff=8'd0;

  assign i2c_sda=(i2c_sda_enable==1)?sda_out:'bz;
  assign i2c_scl=(i2c_scl_enable==0)?1:i2c_clk;

  always@(posedge clk) begin
    if(counter2==(divide_by/2)-1) begin
      i2c_clk<=~i2c_clk;
      counter2<=0;
    end
    else
      counter2<=counter2+1'b1;
  end

  always@(negedge i2c_clk or posedge rst) begin
    if(rst)
      i2c_scl_enable<=1'b0;
    else begin
      if(state==idle || state==start || state==stop) begin
        i2c_scl_enable<=1'b0;
      end
      else
        i2c_scl_enable<=1'b1;
    end
  end

  always@(posedge i2c_clk or posedge rst) begin
    if(rst) begin
      state<=idle;
      counter<=0;
    end
    else begin
      case(state)
        idle: begin
          if(enable) begin
            state<=start;
            saved_addr<={addr,rw};
            saved_data<=w_data;
          end
          else
            state<=idle;
        end
        start: begin
          counter<=7;
          state<=address;
        end
        address: begin
          if(counter==0)
            state<=read_ack;
          else
            counter<=counter-1'b1;
        end
        read_ack: begin    //slave acknowledges whether it has received addr
          if(i2c_sda==0) begin //that is why i2c_sda is zero means slave sends ack,slave took control over data line
            counter<=7;
            if(saved_addr[0]==0) begin state<=write_data; end
            else state<=read_data;
          end
          else
            state<=stop;
        end
        write_data: begin
          if(counter==0)
            state<=read_ack2;
          else
            counter<=counter-1'b1;
        end
        read_ack2: begin
          if(i2c_sda==0)
            state<=stop; //slave says whether it received data
          else
            state<=idle;
        end
        read_data: begin
          buff[counter]<=i2c_sda;
          if(counter==0)
            state<=write_ack;
          else
            counter<=counter-1'b1;
        end
        write_ack: begin
          dout<=buff;
          state<=stop;
        end
        stop: begin
          state<=idle;
        end
      endcase
    end
  end
    always@(negedge i2c_clk or posedge rst) begin
      if(rst) begin
        i2c_sda_enable<=1'b1; //everything high initially
        sda_out<=1'b1;
      end
      else begin
        case(state)
          start: begin
            i2c_sda_enable<=1'b1; //at negedge of sda operation start
            sda_out<=1'b0;
          end
          address: begin
            i2c_sda_enable<=1'b1; //master connecting sda
            sda_out<=saved_addr[counter];
          end
          read_ack: begin
            i2c_sda_enable<=1'b0; //slave connecting sda
          end
          write_data: begin
            i2c_sda_enable<=1'b1;
            sda_out<=saved_data[counter];
          end
          read_ack2: begin
            i2c_sda_enable<=1'b0;
          end
          read_data: begin
            i2c_sda_enable<=1'b0;
          end
          write_ack: begin
            i2c_sda_enable<=1'b1;
            sda_out<=1'b0;
          end
          stop: begin
            i2c_sda_enable<=1'b1;
            sda_out<=1'b1; //rise of sda means finish
          end
        endcase
      end
    end
endmodule
