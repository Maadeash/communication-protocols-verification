module slave(
  inout sda,
  inout scl
);
  reg [7:0]data_out=0;
  reg [7:0]data_in=0;
  reg [3:0]counter;
  reg sda_out=0;
  reg write_enable=0;
  reg start=0;
  reg [2:0]state;
  localparam SLAVE_ADDR=7'b0101010;
  reg [7:0]recv_address;
  localparam read_addr=0;
  localparam ack1=1;
  localparam read_data=2;
  localparam ack2=3;
  localparam write_data=4;

  assign sda=(write_enable==1)?sda_out:'bz;

  always@(negedge sda) begin
    if(start==0 && scl==1)
      begin
        state<=read_addr;
        start<=1'b1;
        counter<=7;
      end
  end
  always@(posedge sda) begin
    if(start==1 && scl==1)
      begin
        state<=read_addr;
        start<=0;
        write_enable<=0;
      end
  end
  always@(posedge scl) begin
    if(start==1) begin
      case(state)
        read_addr: begin
          recv_address[counter]<=sda;
          if(counter==0) state<=ack1;
          else counter<=counter-1'b1;
        end
        ack1: begin
          if(recv_address[7:1]==SLAVE_ADDR) begin
            counter<=7;
            if(recv_address[0]==0)
              state<=read_data;
            else
              state<=write_data;
          end
        end
        read_data: begin
          data_in[counter]<=sda;
          if(counter==0)
            state<=ack2;
          else
            counter<=counter-1'b1;
        end
        ack2: begin
          state<=read_addr;
          data_out<=data_in;
        end
        write_data: begin
          if(counter==0)
            state<=read_addr;
          else
            counter<=counter-1'b1;
        end
      endcase
    end
  end
  always@(negedge scl) begin
    case(state)
      read_addr: begin
        write_enable<=1'b0;
      end
      ack1: begin
        write_enable<=1'b1;
        sda_out<=1'b0;
      end
      read_data: begin
        write_enable<=1'b0;
      end
      ack2: begin
        write_enable<=1'b1;
        sda_out<=1'b0;

      end
      write_data: begin
        write_enable<=1'b1;
        sda_out<=data_out[counter];
      end
      default: write_enable<=1'b0;
    endcase
  end
endmodule
